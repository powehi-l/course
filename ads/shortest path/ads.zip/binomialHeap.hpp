#ifndef BINOMIAL_HEAP_HPP
#define BINOMIAL_HEAP_HPP

#include "commons.hpp"

struct BinomialNode : public GeneralNode{

};

class BinomialHeap : public GeneralHeap{
    public:

    void initialize(Point *pl,int np){

    }
    GeneralNode deleteMin(){
        
    }
    void insert(int index,ll dist){
        
    }
    void decreaseKey(int idx,ll newVal){

    }
    bool isEmpty(){

    }
    void free(){
        
    }

};


#endif