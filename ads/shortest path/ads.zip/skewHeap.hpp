#ifndef SKEW_HEAP_HPP
#define SKEW_HEAP_HPP

#include "commons.hpp"

struct SkewNode : public GeneralNode{

};

class SkewHeap : public GeneralHeap{
    public:

    void initialize(Point *pl,int np){

    }
    GeneralNode deleteMin(){
        
    }
    void insert(int index,ll dist){
        
    }
    void decreaseKey(int idx,ll newVal){

    }
    bool isEmpty(){

    }
    void free(){
        
    }
};


#endif