#ifndef PARING_HEAP_HPP
#define PARING_HEAP_HPP

#include "commons.hpp"

struct ParingNode : public GeneralNode{

};

class ParingHeap : public GeneralHeap{
    public:

    void initialize(Point *pl,int np){

    }
    GeneralNode deleteMin(){
        
    }
    void insert(int index,ll dist){
        
    }
    void decreaseKey(int idx,ll newVal){

    }
    bool isEmpty(){

    }
    void free(){
        
    }
};

#endif