命令行编译参数：g++ -Wall -g -o bin/test.exe src/* 
（可选：-DDEBUG，启用程序中的DEBUG部分）

可执行文件生成在根目录下的bin文件夹中

测试示例：bin/test.exe < testing_data/sample1.in

也可以使用vscode打开code文件夹，用code runner运行。