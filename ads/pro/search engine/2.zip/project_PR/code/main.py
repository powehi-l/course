# from typing import List, Any

import nltk

# nltk.download('punkt')
# nltk.download('stopwords')
from nltk.stem.porter import PorterStemmer
from nltk.corpus import stopwords
import os


# import json


# import time


def stopword():
    path = "ce"
    path1 = "ce1"
    for filename in os.listdir(path):
        position = path + "//" + filename
        a = open(position, 'r', encoding='utf-16')  # 读取下载好的莎士比亚文集
        b = open(path1 + "//stop" + filename, 'w')  # 在另一个文件夹中保存处理后的文件
        for line in a:
            text = nltk.word_tokenize(line)  # word分割语句
            new_word = [word for word in text if word not in stopwords.words('English')]
            b.write(' '.join(new_word))  # 用空格来将分割好的word写入文件当中
            b.write('\n')
        a.close()
        b.close()
        print(filename)


def stemmingword():
    path = "ce1"
    path2 = "ce2"
    for filename in os.listdir(path):
        position = path + "//" + filename
        a = open(position, 'r')
        b = open(path2 + "//st" + filename, 'w')
        for line in a:
            p = line.split()  # 分割每一行的word
            for word in p:  # 先将给定库中的stemword读取出来，然后进行转换，再写入另一个文件中
                stem_word = PorterStemmer()
                b.write(stem_word.stem(word))
                b.write(" ")
            b.write("\n")  # 格式设置
        a.close()
        b.close()
        print(filename)


def invertedindex():
    # wordnum = 0
    path = "ce2"
    path2 = "ce3"
    for filename in os.listdir(path):
        a = open(path + "//" + filename, 'r')

        file = filename[6:]  # 把前面的前缀给去掉
        linenum = 0  # linenum记录当前文件的行数
        for line in a:
            linenum += 1
            # wordnum = 0  # wordnum记录当前行的单词数
            t = line.split()
            for word in t:
                # wordnum += 1
                if word not in minidic:
                    item = [file, linenum]  # 保存该word出现的地址
                    index = []
                    index.append(item)  # 并加入到这个单次的索引中去
                    minidic[word] = index  # 存到字典当中去

                else:
                    item = [file, linenum]
                    minidic[word].append(item)
        # print(minidic.items())
        a.close()

    b = open(path2 + "//" + "all.txt", 'w')
    for key in minidic:
        b.write(key)
        b.write("    ")
        b.write(str(minidic[key]))
        b.write(" ")
        #  b.write(len(minidic[i]))
        b.write("\n")
    b.close()

    # print(filename)
    # print("finish count")


def searchsen():
    senten = input()  # 读入一句话
    stopsenten = nltk.word_tokenize(senten)
    splword = [word for word in stopsenten if word not in stopwords.words('English')]  # 去除stop word
    # (splword)
    searchlist = []
    interlist = []
    i = 0
    for word in splword:
        # print(word)

        porter_stem = PorterStemmer()
        # print(porter_stem.stem(word))
        word = porter_stem.stem(word)  # 将需要进行检索的内容存储到列表中
        print(word)
        if word not in minidic:
            print("no solution")
            # print(word)
        else:
            # print(minidic[word])
            # print(word)
            searchlist.append(minidic[word])
            # searchlist[i] = minidic[word]
            i += 1
    # print(searchlist)
    # print(searchlist[0])
    # print(searchlist[1])

    # for pos in searchlist[0]:
        # for pos1 in searchlist[1]:
            # if pos == pos1:
                # print(pos)
    for j in range(0,i):
        for pos in searchlist[j]:
            for k in range(0,i):
                for pos1 in searchlist[k]:
                    if(pos==pos1 and k!=j):
                        interlist.append(pos)
    print(interlist)


    # set1 = set(searchlist[0])
    # set2 = set(searchlist[1])
    # iset = set1.intersection(set2)
    # print(iset)


# def searchword():


if __name__ == "__main__":
    minidic = {}  # 创建字典来存储索引
    # dicto = {}
    # stopword()
    # stemmingword()
    invertedindex()
    # print(minidic.items())
    # dicto = sorted(minidic.items(), key=lambda x: len(x), reverse=False)
    # print(dicto)
    searchsen()
