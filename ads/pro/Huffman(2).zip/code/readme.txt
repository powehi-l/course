1. First open src/huffman.cpp. And compile it with minGW. Using the sample in test.
2. If failing compiling huffman, please use build/huffman.exe to test the program.