#include<iostream>
using namespace std;

class rectangle {
private:
	int l;//length
	int w;//width and consider it as height too
public:
	rectangle() :l(0), w(0) {};
	rectangle(int i, int j) {
		l = i;
		w = j;
	}
	int getl();
	int getw();
	bool operator<=(const rectangle& operand2);
	bool operator>(const rectangle& operand2);
};

void quicksort(rectangle* input, int begin, int end);//sort the input rectangle in descending order
int max(int* input, int n);//return the max integer in particular range

int main(void) {
	bool left;
	int width, N, i, m, n, * height, loc, maxi, j;
	rectangle* input;
	cout << "Input the width of the bin:" << endl;
	cin >> width;
	cout << "Input the number of the rectangles:" << endl;
	cin >> N;
	input = new rectangle[N];
	height = new int[width];
	cout << "Input length and width of rectangles, each record occupies one line:" << endl;
	for (i = 0; i < width; i++) {
		height[i] = 0;
	}
	for (i = 0; i < N; i++) {
		cin >> m >> n;
		if (m == width) {//if one of the side length is same with width of bin, consider this side as length
			input[i] = rectangle(m, n);
		}
		else if (n == width) {
			input[i] = rectangle(n, m);
		}
		else if (m >= n) {//else consider the shorter side as height
			input[i] = rectangle(m, n);
		}
		else input[i] = rectangle(n, m);
	}
	quicksort(input, 0, N);
	left = false;//left is a vairable indicates the packing direction, true for packing from right to left and false otherwise
	loc = 0;//loc indicates the first avaiable horizontal location for next rectangle
	for (i = 0; i < N; i++) {
		if (left) {
			if (loc + 1 < input[i].getl()) {//if we couldn't pack this rectangle in current line
				loc = 0;//pack this rectangle in a new line
				left = !left;//and change the direction
			}
		}
		else {
			if (width - loc < input[i].getl()) {
				left = !left;
				loc = width - 1;
			}
		}
		if (left) {
			maxi = max(height + loc - input[i].getl() + 1, input[i].getl());
			height[loc] = maxi + input[i].getw();//the height afetr packing this rectangle is determined by the largest height below it and it's height
			for (j = loc - 1; j > loc - input[i].getl(); j--) {
				height[j] = height[j + 1];
			}
			loc = loc - input[i].getl();//change the loc to next available location
		}
		else {
			maxi = max(height + loc, input[i].getl());
			height[loc] = maxi + input[i].getw();
			for (j = loc + 1; j < loc + input[i].getl(); j++) {
				height[j] = height[j - 1];
			}
			loc = loc + input[i].getl();
		}
	}
	maxi = max(height, N);
	cout << maxi;
}

int rectangle::getl() {
	return l;
}

int rectangle::getw() {
	return w;
}

void quicksort(rectangle* input, int begin, int end) {
	if (begin + 1 >= end) {
		return;
	}
	int first = begin, last = end - 1;
	rectangle key = input[first];
	while (first < last) {
		while (first < last && input[last] <= key) last--;
		input[first] = input[last];
		while (first<last && input[first] > key) first++;
		input[last] = input[first];
	}
	input[first] = key;
	quicksort(input, begin, first);
	quicksort(input, first + 1, end);
}

int max(int* input, int n) {
	int i, maxi;
	maxi = input[0];
	for (i = 0; i < n; i++) {
		if (input[i] > maxi) {
			maxi = input[i];
		}
	}
	return maxi;
}

bool rectangle::operator<=(const rectangle& operand2) {
	if (w < operand2.w) {//the rectangle with shorter width is prefered
		return true;
	}
	else if (w == operand2.w && l >= operand2.l) {//same width the rectangle with shorter length is prefered
		return true;
	}
	else return false;
}

bool rectangle::operator>(const rectangle& operand2) {
	if (w > operand2.w) {
		return true;
	}
	else if (w == operand2.w && l < operand2.l) {
		return true;
	}
	else return false;
}