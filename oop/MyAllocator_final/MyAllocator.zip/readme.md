1. compile test.cpp and test_pta.cpp with c++11

    g++ -std=c++11 test.cpp -o test
    g++ -std=c++11 test_pta.cpp -o test_pta

2. or you can just run the .exe file

    attention: exe can not be include in zip when uploading zip to PTA, so I compress exe in the file first