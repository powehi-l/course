1. There is six source file where one is header file "Diary.h". And another one is "Diary.cpp" which consists of the defination of declarition in "Diary.h". The Rest is the four program.

2. after you unzip the file, please first compile these program in your command line with

   ```shell
   g++ Diary.cpp pdadd.cpp -o pdadd
   g++ Diary.cpp pdlist.cpp -o pdlist
   g++ Diary.cpp pdshow.cpp -o pdshow
   g++ Diary.cpp pdremove.cpp -o pdremove
   ```

3. And then if you are using the linux or macos, just run the test.sh in shell.
   And if you are using windows, please be sure you have installed git or other shell.

   run the test.sh in shell.